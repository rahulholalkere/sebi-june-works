/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.gradebook.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.base.AssignmentLocalServiceBaseImpl;
import com.liferay.training.gradebook.validator.AssignmentValidator;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author rahulholalkere
 */
@Component(
	property = "model.class.name=com.liferay.training.gradebook.model.Assignment",
	service = AopService.class
)
public class AssignmentLocalServiceImpl extends AssignmentLocalServiceBaseImpl {
	/**
	 * For Adding New Assignment
	 * 
	 * @param groupId
	 * @param titleMap
	 * @param descriptionMap
	 * @param dueDate
	 * @param serviceContext
	 * @return
	 * @throws PortalException
	 */
	public Assignment addAssignment(long groupId, Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate, ServiceContext serviceContext) throws PortalException {
		// Validate Assignment Field Values
		assignmentValidator.validate(titleMap, descriptionMap, dueDate);
		
		// Need Details About Group (Website Info) and User Information
		long currentUserId = serviceContext.getUserId();
		User currentUser = userLocalService.getUser(currentUserId);
		
		Group currentGroup = groupLocalService.getGroup(groupId);
		
		// Generate A New Primary Key For Create A New Assignment
		long assignmentId = counterLocalService.increment(Assignment.class.getName());
		
		// Using Generated Key Create A New Assignment
		Assignment assignment =  createAssignment(assignmentId);
		
		// Populate Assignment Information To The Newly Created Assignment
		// 1. Updating Actual Assignment Fields
		assignment.setTitleMap(titleMap);
		assignment.setDescriptionMap(descriptionMap);
		assignment.setDueDate(dueDate);
		
		// 2. Updating Other Necessary Fields For Assignment
		assignment.setGroupId(groupId);
		assignment.setCompanyId(currentGroup.getCompanyId());
		assignment.setCreateDate(new Date());
		assignment.setModifiedDate(new Date());
		assignment.setUserId(currentUserId);
		assignment.setUserName(currentUser.getScreenName());
		
		// Persist Assignment Information Before Making It A Resource
		assignment = super.addAssignment(assignment);
		
		// Adding UI and User (Guest and Site Member) Information To Make Assignment A Permissioned Resource
		boolean portletActions = false;
		boolean addGuestPermissions = true;
		boolean addGroupPermissions = true;
		
		// Make A Call The Resource Service To Make It A Permissioned Resource
		resourceLocalService.addResources(currentGroup.getCompanyId(), groupId, currentUserId, Assignment.class.getName(), assignmentId, portletActions, addGroupPermissions, addGuestPermissions);
		
		// Return The Assignment As Per Usual Flow.
		return assignment;
	}
	
	public Assignment deleteAssignment(Assignment assignment) throws PortalException {
		// Delete The Permissioned Resource
		resourceLocalService.deleteResource(assignment, ResourceConstants.SCOPE_INDIVIDUAL);
		
		// Delete The Assignment As well
		return assignmentLocalService.deleteAssignment(assignment);
	}
	
	/**
	 * For Updating The Existing Assignment Based On Edit Request
	 * 
	 * @param assignmentId
	 * @param titleMap
	 * @param descriptionMap
	 * @param dueDate
	 * @param serviceContext
	 * @return
	 * @throws PortalException
	 */
	public Assignment updateAssignment(long assignmentId, Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate, ServiceContext serviceContext) throws PortalException {
		// Validate Assignment Field Values
		assignmentValidator.validate(titleMap, descriptionMap, dueDate);
		
		// Get The Assignment Information Based On The AssignmentId
		Assignment assignment = getAssignment(assignmentId);
		
		// Populate Assignment Information To The Update The Assignment
		// 1. Updating Actual Assignment Fields
		assignment.setTitleMap(titleMap);
		assignment.setDescriptionMap(descriptionMap);
		assignment.setDueDate(dueDate);
		
		// Update The Modification Date
		assignment.setModifiedDate(new Date());
		
		// Persist and Return The Assignment
		return super.updateAssignment(assignment);
	}
	
	/**
	 * 
	 * Utility To Find Assignment List Based On GroupId Only
	 * 
	 * @param groupId
	 * @return
	 */
	public List<Assignment> getAssignmentByGroupId(long groupId) {
		return assignmentPersistence.findByGroupId(groupId);
	}
	
	/**
	 * 
	 * Utility To Find Assignment List Based On GroupId and Start and End Position
	 * 
	 * @param groupId
	 * @return
	 */
	public List<Assignment> getAssignmentByGroupId(long groupId, int start, int end) {
		return assignmentPersistence.findByGroupId(groupId, start, end);
	}
	
	/**
	 * 
	 * Utility To Find Assignment List Based On GroupId and Start and End Position with Comparison Operator
	 * 
	 * @param groupId
	 * @return
	 */
	public List<Assignment> getAssignmentByGroupId(long groupId, int start, int end, OrderByComparator<Assignment> orderByComparator) {
		return assignmentPersistence.findByGroupId(groupId, start, end, orderByComparator);
	}
	
	// Getting The Search Done Based On The Keywords
	private DynamicQuery getKeywordsSearchDynamicQuery(long groupId, String keywords) {
		// Creating a Dynamic Query For The Specific Website where Search Needs To Be Performed.
		DynamicQuery dynamicQuery = dynamicQuery().add(RestrictionsFactoryUtil.eq("groupId", groupId));
		
		// Hoping We Have Something In Keywords
		if(Validator.isNotNull(keywords)) {
			// Provide A Base Where We Will Provide Information How To Perform The Search (Like or Other Formats)
			Disjunction disjunctionQuery = RestrictionsFactoryUtil.disjunction();
			
			disjunctionQuery.add(RestrictionsFactoryUtil.like("title", "%" + keywords + "%"));
			disjunctionQuery.add(RestrictionsFactoryUtil.like("description", "%" + keywords + "%"));
			
			// Adding The Disjuntion Condition To The Dynamic Query
			dynamicQuery.add(disjunctionQuery);
		}
		
		return dynamicQuery;
	}
	
	// Getting List Of Assignment Based On GroupId and Keywords
	public List<Assignment> getAssignmentByKeywords(long groupId, String keywords, int start, int end, OrderByComparator<Assignment> orderByComparator) {
		return assignmentLocalService.dynamicQuery(getKeywordsSearchDynamicQuery(groupId, keywords), start, end, orderByComparator);
	}
	
	// Getting Assignment Count Based On GroupId and Keywords
	public long getAssignmentsCountByKeywords(long groupId, String keywords) {
		return assignmentLocalService.dynamicQueryCount(getKeywordsSearchDynamicQuery(groupId, keywords));
	}
	
	/**
	 * Silence Or Avoiding The Inheritence In Further Levels
	 */
	@Override
	public Assignment addAssignment(Assignment assignment) {
		throw new UnsupportedOperationException("Not Supported");
	}
	
	@Override
	public Assignment updateAssignment(Assignment assignment) {
		throw new UnsupportedOperationException("Not Supported");
	}
	
	@Reference
	private AssignmentValidator assignmentValidator;
}