package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;
import com.liferay.training.gradebook.web.display.context.AssignmentsManagementToolbarDisplayContext;
import com.liferay.training.gradebook.web.internal.security.permission.resource.AssignmentPermission;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This Class Represent For Rendering Event Before Showing All The Assignment In The Main View
 * @author rahulholalkere
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=/",
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENTS
	},
	service = MVCRenderCommand.class
)
public class ViewAssignmentsMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Adding Assignment Management Toolbar Like What We Usually See While Working User's and Organization Views
		addManagementToolbarAttributes(renderRequest, renderResponse);
		
		// Adding Actual Assignment Related Information To The Request For Rendering On Actual Views (JSP)
		addAssignmentRelatedAttributes(renderRequest);
		
		// Adding AssignmentPermission To The Request
		renderRequest.setAttribute("assignmentPermission", assignmentPermission);
		
		// Redirecting To Appropriate JSP View
		return "/view.jsp";
	}
	
	private void addManagementToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		// We Will Need To Instantiate Assignment Clay Management Toolbar Class with LiferayPortletRequest, Response And Page Request
		LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
		LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
		HttpServletRequest httpServletRequest = portal.getHttpServletRequest(renderRequest);
		
		// We Need To Instanciate The Assignment Clay Management Toolbar Class and Set The Attributes To The Request For View JSP To Use It.
		AssignmentsManagementToolbarDisplayContext assignmentsManagementToolbarDisplayContext = new AssignmentsManagementToolbarDisplayContext(liferayPortletRequest, liferayPortletResponse, httpServletRequest);
		renderRequest.setAttribute("assignmentsManagementToolbarDisplayContext", assignmentsManagementToolbarDisplayContext);
	}

	/**
	 * Adds Assignment Related List Information To Request Parameter
	 * 
	 * @param renderRequest
	 */
	private void addAssignmentRelatedAttributes(RenderRequest renderRequest) {
		// Resolve The Start and End Of The Search Container Where The Result Will Be Listed.
		int currentPage = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_CUR);
		int delta = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_DELTA_PARAM, SearchContainer.DEFAULT_DELTA);
		
		int start = ((currentPage > 0) ? (currentPage - 1) : 0) * delta;
		int end = start + delta;
		
		// Getting The Sorting Information From The Search Container Or Defaults
		String orderByCol = ParamUtil.getString(renderRequest, "orderByCol", "title");
		String orderByType = ParamUtil.getString(renderRequest, "orderByType", "asc");
		
		// Getting Keywords If Available
		String keywords = ParamUtil.getString(renderRequest, "keywords");
		
		// Create A OrderbyComparator Which Will Be Also Used For Getting The List Of Assignments
		OrderByComparator<Assignment> orderByComparator = OrderByComparatorFactoryUtil.create("Assignment", orderByCol, !("asc").equals(orderByType));
		
		// For Assignment Retrival Process Get The GroupId Or WebsiteId From Where The Request Has Originated.
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
				
		// Call For Assignment Services From Getting The List Of Assignment And Related Count Information
		List<Assignment> assignments = assignmentService.getAssignmentByKeywords(groupId, keywords, start, end, orderByComparator);
		long assignmentsCount = assignmentService.getAssignmentsCountByKeywords(groupId, keywords);
		
		// Passing The List And Count Information To The Request Which Will Be Used In The Appropriate Views.
		renderRequest.setAttribute("assignments", assignments);
		renderRequest.setAttribute("assignmentsCount", assignmentsCount);
	}

	@Reference
	private AssignmentService assignmentService;
	
	@Reference
	private AssignmentPermission assignmentPermission;
	
	@Reference
	private Portal portal;
}
